package com.bot;

import java.io.InputStream;
import java.net.URL;

import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;

import com.klab.ctx.ConversationSession;
import com.klab.data.RDBAdapter;
import com.klab.svc.SimpleAppFrame;
import com.klab.svc.AppsPropertiy;
import com.klab.svc.ConversationLogger;
import com.pengrad.telegrambot.TelegramBot;
import com.pengrad.telegrambot.TelegramBotAdapter;
import com.pengrad.telegrambot.UpdatesListener;
import com.pengrad.telegrambot.model.Message;
import com.pengrad.telegrambot.model.Update;
import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.request.SendMessage;
import com.pengrad.telegrambot.request.SendPhoto;
import com.klab.svc.ILogger;

public class BendingMachinBOT extends Thread implements UpdatesListener 
{
	static class CHAT {
		public long chatId;
		public String message;
	}
	
	private BlockingQueue<CHAT> queue;
	private SimpleAppFrame appFrame;
	private ConversationLogger convLogger;
	private ConversationSession session = null;
	private TelegramBot telegram;
	
	public BendingMachinBOT() {
		queue = new ArrayBlockingQueue<CHAT>(100);
	}
	
	/*
	 * 서비스 준비 작업을 수행한다. 
	 * 
	 * @return true - 서비스 준비 완료
	 */
	private boolean prepare() {
		boolean rs = true;
		
		try {
			RDBAdapter.getInstance().getDB();
			String username = AppsPropertiy.getInstance().getProperty("wcs.user");
			String password = AppsPropertiy.getInstance().getProperty("wcs.passwd");
			String workId = AppsPropertiy.getInstance().getProperty("wcs.workid");
			
			/*
			 * Simple Frame for Aplication 
			 */
			
			appFrame = new SimpleAppFrame();
			appFrame.setUsername(username);
			appFrame.setPassword(password);
			appFrame.setWorkspaceId(workId);
			
			session = new ConversationSession();
			
			/*
			 * 대화를 저장할 로거를 생성 
			 */
			convLogger = new ConversationLogger();
			
			String logger = AppsPropertiy.getInstance().getInstance().getProperty("logger.className");
			if ( logger != null && logger.length() > 0 ) {
				try {
					convLogger.setLogger((ILogger)Utils.loadClass(logger));
				} catch (Exception e) {
					convLogger.setLogger(new ConsoleLogger());
				}
			}
			else {
				convLogger.setLogger(new ConsoleLogger());
			}
			
			convLogger.start();
			
			/*
			 * 텔레그램 
			 */
			telegram = 
					TelegramBotAdapter.build(AppsPropertiy.getInstance().getProperty("telegram.token"));
			
			telegram.setUpdatesListener(this);
		
		}catch(Exception e) {
			e.printStackTrace();;
			rs = false;
		}
		
		return rs;
	}
	
	/* (non-Javadoc)
	 * @see java.Lang.Thread#run()
	 */
	public void run() {
		if (!prepare() ) {
			System.out.println("@.@ System error");
			return ;
		}
		
		System.out.println("@.@ ready. . . ");
		boolean running = true;
		try {
			while(running) {
				CHAT msg = queue.poll(500, TimeUnit.MICROSECONDS);
				if (msg != null) {
					receiveMessage(msg);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			running = false;
		}
		
		convLogger.shutdown();
	}
	
	/*
	 * 텍스트를 텔레그램으로 전송한다. 
	 * 
	 * @param chatId CHAT ID
	 * @param message 문자열 메세지
	 * 
	 */
	private void sendText(long chatId, String message) {
		SendMessage request = new SendMessage(chatId, message)
				.parseMode(ParseMode.Markdown)
				.disableWebPagePreview(true)
				.disableNotification(true);
		
		telegram.execute(request);
	}
	
	/*
	 * 이미지를 텔레그램으로 전송한다. 
	 * 
	 * @param chatId CHAT ID
	 * @param url 이미지 URL
	 */
	private void sendPhoto(long chatId, String url) {
		InputStream in = null;
		try {
			in = new URL( url ).openStream();
			
			SendPhoto photo = new SendPhoto(chatId, IOUtils.toByteArray(in))
					.disableNotification(true);
			
			telegram.execute(photo);
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			IOUtils.closeQuietly(in);
		}
	}
	
	/*
	 * 수신된 메세지를 처리한다. 
	 * @param text
	 */
	@SuppressWarnings("unchecked")
	private void receiveMessage(CHAT msg) {
		try {
			if ( "/start".equals(msg.message) ) {
				session.getContext().clear();
				appFrame.message(session,  "");
			}
			else
				appFrame.message(session,  msg.message);
			
			/*
			 *  대화 이력을 저장한다.
			 */
			convLogger.addDialog(session);
			
			StringBuffer resText = new StringBuffer();
			List<String> list = session.getOutputString();
			for(int i = 0; i<list.size();i++) {
				resText.append(list.get(i));
				if( i<list.size()-1)
					resText.append("<br>");
			}
			
			sendText(msg.chatId, resText.toString()); //chatId
			
			//사진
			if ( session.getPostResult() != null) {
				String url = 
session.getPostResult().getAsJsonObject().get("PROD_IMAGE").getAsString();
						sendPhoto(msg.chatId, url);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			sendText(msg.chatId, ex.getMessage());
		}
	}
	/*
	 * 테렐그램에서 메세지를 수신 
	 * 
	 * (non-Javadoc)
	 * @see com.pengrad.telegrambot.UpdatesListener#process(java.util.List)
	 */
	@Override
	public int process(List<Update> updates ) {
		Message msg = updates.get(0).message();
		if (msg.text() != null ) {
			try {
				CHAT c = new CHAT();
				c.chatId = msg.chat().id();
				c.message = msg.text();
				
				queue.put(c);
			} catch (InterruptedException e) {}
		}
		
		return UpdatesListener.CONFIRMED_UPDATES_ALL; // process updates
	}
	
	/*
	 * @param args 
	 */
	
	public static void main(String[] args) {
		BendingMachinBOT bot = new BendingMachinBOT();
		bot.start();
		
		try {
			bot.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}