package org.hdcd.service;

import java.util.List;

import org.hdcd.domain.Platform;
import org.hdcd.mapper.BoardMapper;
import org.hdcd.mapper.PlatformMapper;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class PlatformServiceImpl implements PlatformService{

	private final PlatformMapper mapper;
	@Override
	public List<Platform> netflex() throws Exception {
		return mapper.netflex();
	}

	@Override
	public List<Platform> wave() throws Exception {
		return mapper.wave();
	}

	@Override
	public List<Platform> watcha() throws Exception {
		return mapper.watcha();
	}

	@Override
	public List<Platform> disney() throws Exception {
		return mapper.disney();
	}

	@Override
	public List<Platform> coupangplay() throws Exception {
		return mapper.coupangplay();
	}

	@Override
	public List<Platform> tving() throws Exception {
		return mapper.tving();
	}

//	@Override
//	public void create(Platform platform) throws Exception {
//		
//	}

}
