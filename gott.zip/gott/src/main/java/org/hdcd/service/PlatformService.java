package org.hdcd.service;

import java.util.List;

import org.hdcd.domain.Platform;

public interface PlatformService {

	
	public List<Platform> netflex () throws Exception;
	
	public List<Platform> wave () throws Exception;
	
	public List<Platform> watcha () throws Exception;
	
	public List<Platform> disney () throws Exception;
	
	public List<Platform> coupangplay () throws Exception;

	public List<Platform> tving () throws Exception;
	
//	public void create(Platform platform) throws Exception;

}