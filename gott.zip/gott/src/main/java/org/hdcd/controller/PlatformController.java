package org.hdcd.controller;

import org.hdcd.domain.Platform;
import org.hdcd.service.PlatformService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
@RequestMapping("/platform")
public class PlatformController {

	private final PlatformService service;
	
//	@GetMapping("/register")
//	public void register(){
//		
//	}
	
	@RequestMapping("/netflex")
	public String netflex(Model model)throws Exception{
		model.addAttribute("list", service.netflex());
		return"/platform/netflex";
	}
	@RequestMapping("/wave")
	public String wave(Model model)throws Exception{
		model.addAttribute("list", service.wave());
		return"/platform/wave";
	}
	
	@RequestMapping("/coupangplay")
	public String coupangplay(Model model)throws Exception{
		model.addAttribute("list", service.coupangplay());
		return"/platform/coupangplay";
	}
	
	@RequestMapping("/disney")
	public String disney(Model model)throws Exception{
		model.addAttribute("list", service.disney());
		return"/platform/disney";
	}
	
	@RequestMapping("/watcha")
	public String watcha(Model model)throws Exception{
		model.addAttribute("list", service.watcha());
		return"/platform/watcha";
	}
	
	@RequestMapping("/tving")
	public String tving(Model model)throws Exception{
		model.addAttribute("list", service.tving());
		return"/platform/tving";
	}
	
	@RequestMapping("/*/viewcontent")
	public String viewcontent(Model model)throws Exception{
		
		return"/platform/viewcontent";
	}
	
}
