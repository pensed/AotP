package org.hdcd.mapper;

import java.util.List;

import org.hdcd.domain.Platform;

public interface PlatformMapper {

	public List<Platform> netflex () throws Exception;
	
	public List<Platform> wave () throws Exception;
	
	public List<Platform> watcha () throws Exception;
	
	public List<Platform> disney () throws Exception;
	
	public List<Platform> coupangplay () throws Exception;
	
	public List<Platform> tving () throws Exception;
	
//	public void create(Platform platform) throws Exception;
}
